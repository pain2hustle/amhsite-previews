
(function () {
  var R = document.documentElement;
  var m = document.querySelector('meta[name="theme-color"]');
  if (!m) { m = document.createElement('meta'); m.name = 'theme-color'; document.head.appendChild(m); }
  var NAV = '#190d27', TOUCH = '#110b1b', cur = '';
  function set() {
    var c = R.classList.contains('rl-touch') ? TOUCH : NAV;
    if (c !== cur) { cur = c; m.setAttribute('content', c); }
  }
  set();
  try { new MutationObserver(set).observe(R, { attributes: true, attributeFilter: ['class'] }); } catch (e) {}
  // installable app (Chrome / Edge / Samsung): a pass-through service worker, no caching
  if ('serviceWorker' in navigator) {
    addEventListener('load', function () { navigator.serviceWorker.register('/major-league-cuts-studio-2/sw.js').catch(function () {}); });
  }
})();
