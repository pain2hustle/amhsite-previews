(function(){"use strict";
var film=document.getElementById("film"),fw=film&&film.querySelector(".fw"),main=document.getElementById("top"),cr=document.querySelector(".fly-crown"),plate=document.querySelector(".crown-float"),nav=document.querySelector("nav.nav");
if(!film||!fw||!main||!cr)return;
var root=document.documentElement,mq=matchMedia("(prefers-reduced-motion: reduce)"),raf=0;
function clamp(v,a,b){return Math.min(b,Math.max(a,v));}
function frame(){raf=0;var vw=innerWidth,vh=innerHeight||root.clientHeight,header=nav?nav.getBoundingClientRect().height:84;
root.style.setProperty("--amh-handoff-vh",vh+"px");root.style.setProperty("--amh-header-height",header+"px");
var box=film.getBoundingClientRect(),travel=film.offsetHeight-vh,active=root.classList.contains("amh-film-ready")&&travel>0,p=active?clamp(-box.top/travel,0,1):0,done=!active||p>=1-1/Math.max(travel,1);
fw.style.setProperty("--fo",(active?clamp((p-.9)/.07,0,1):0).toFixed(3));
var visible=(mq.matches||done)?1:clamp((p-.98)/.02,0,1);root.style.setProperty("--amh-main-opacity",visible.toFixed(3));
main.inert=!mq.matches&&!done;
main.style.pointerEvents=(!mq.matches&&!done)?"none":"";
var cw=cr.offsetWidth||300,ch=cr.offsetHeight||cw*.78,sx=(vw-cw)/2,sy=vh*.42-ch/2,x=sx,y=sy,scale=1,opacity=clamp((p-.92)/.035,0,1);
var ir=plate?(plate.querySelector("img")||plate).getBoundingClientRect():null;
if(ir&&ir.width){var e=clamp((p-.955)/.045,0,1);e=e*e*(3-2*e);var targetScale=ir.width/cw,targetY=Math.min(ir.top,vh-ch*targetScale-24);x=sx+(ir.left-sx)*e;y=sy+(targetY-sy)*e;scale=1+(targetScale-1)*e;}
if(p<=0||done||box.bottom<0||mq.matches)opacity=0;
cr.style.transform="translate("+x.toFixed(1)+"px,"+y.toFixed(1)+"px) scale("+scale.toFixed(3)+")";cr.style.opacity=opacity.toFixed(3);cr.style.visibility=opacity>.01?"visible":"hidden";
if(plate)plate.style.opacity=(p>=.955&&opacity>.01)?"0":"";
}
function queue(){if(!raf)raf=requestAnimationFrame(frame);}
root.classList.add("amh-handoff-ready");addEventListener("scroll",queue,{passive:true});addEventListener("resize",queue);addEventListener("load",queue);addEventListener("hashchange",queue);
if(mq.addEventListener)mq.addEventListener("change",queue);else if(mq.addListener)mq.addListener(queue);
if(document.fonts)document.fonts.ready.then(queue);
if(typeof ResizeObserver!=="undefined"&&nav)new ResizeObserver(queue).observe(nav);
if(typeof MutationObserver!=="undefined")new MutationObserver(queue).observe(root,{attributes:true,attributeFilter:["class"]});
frame();
})();
