(function(){"use strict";
var root=document.documentElement,hero=document.querySelector('.hero'),copy=hero&&hero.querySelector('.hero-copy'),card=hero&&hero.querySelector('.hero-card'),actions=hero&&hero.querySelector('.hero-actions'),ps=card&&card.querySelector('.price-stack'),yp=hero&&hero.querySelector('.hero-proof'),cn=hero&&hero.querySelector('.community-note'),snip=hero&&hero.querySelector('.snip'),clip=hero&&hero.querySelector('.clip-shot');
if(!hero||!copy||!card||!actions||!ps||!yp||!cn||!snip||!clip)return;
var psHome=ps.parentNode,psNext=ps.nextSibling,ypHome=yp.parentNode,ypNext=yp.nextSibling,mq=matchMedia('(max-width:900px)'),rm=matchMedia('(prefers-reduced-motion: reduce)'),raf=0,active=false;
var shearImages=[snip.querySelector('img.a'),snip.querySelector('img.b'),snip.querySelector('img.p')],clipImage=clip.querySelector('img.shot');
function failed(img){return !img||(img.complete&&img.naturalWidth===0);}
function setFlag(name,on){if(on)root.classList.add(name);else root.classList.remove(name);}
function measure(){raf=0;if(!active)return;var hr=hero.getBoundingClientRect(),ar=actions.getBoundingClientRect();hero.style.setProperty('--tt',Math.round(ar.bottom-hr.top)+'px');
var shearMissing=shearImages.some(failed),clipMissing=failed(clipImage);setFlag('amh-phone-snip-unavailable',shearMissing);setFlag('amh-phone-clip-unavailable',clipMissing);
// Conservative visible-pixel envelope of the unchanged original layers (including every snip pose).
// Native CSS aspect/origin:2000/1140 and47.119140625%/47.448522829%; reduced motion retains38deg.
var width=snip.offsetWidth,space;if(!shearMissing&&width>0){space=284+(width+1)*(rm.matches?.621:.576)+9;}
else if(!clipMissing){space=Math.max(0,-30+clip.offsetHeight+2)+8;}
else{space=16;}
if(Number.isFinite(space))hero.style.setProperty('--amh-phone-tool-space',Math.ceil(space)+'px');}
function queue(){if(!raf)raf=requestAnimationFrame(measure);}
function layout(){if(mq.matches&&!active){copy.insertBefore(ps,cn);ps.classList.add('ps-up');copy.insertBefore(yp,cn.nextSibling);yp.classList.add('yp-down');active=true;root.classList.add('amh-royal-phone-ready');measure();queue();}
else if(!mq.matches&&active){psHome.insertBefore(ps,psNext);ypHome.insertBefore(yp,ypNext);ps.classList.remove('ps-up');yp.classList.remove('yp-down');active=false;root.classList.remove('amh-royal-phone-ready','amh-phone-snip-unavailable','amh-phone-clip-unavailable');hero.style.removeProperty('--amh-phone-tool-space');}
else queue();}
if(mq.addEventListener)mq.addEventListener('change',layout);else mq.addListener(layout);if(rm.addEventListener)rm.addEventListener('change',queue);else if(rm.addListener)rm.addListener(queue);addEventListener('resize',layout);addEventListener('load',queue);shearImages.concat([clipImage]).forEach(function(img){if(img){img.addEventListener('load',queue);img.addEventListener('error',queue);}});if(document.fonts)document.fonts.ready.then(queue);layout();
})();
