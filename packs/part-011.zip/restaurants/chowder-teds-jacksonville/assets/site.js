(function(){
var R=document.documentElement;
var t=document.getElementById('menuToggle'),m=document.getElementById('mobileMenu');
if(t&&m){t.addEventListener('click',function(){var o=m.classList.toggle('open');t.classList.toggle('open',o);t.setAttribute('aria-expanded',o)});
  m.addEventListener('click',function(e){if(e.target.closest('a')){m.classList.remove('open');t.classList.remove('open');t.setAttribute('aria-expanded','false')}})}
var H=null,TZ="America/New_York";
var DN=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
function pt(){var p=new Intl.DateTimeFormat('en-US',{timeZone:TZ,weekday:'short',hour:'numeric',minute:'numeric',hour12:false}).formatToParts(new Date()),o={};p.forEach(function(x){o[x.type]=x.value});
  return{d:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(o.weekday),h:(+o.hour%24)+(+o.minute)/60}}
function fmt(h){h=h%24;var hr=Math.floor(h),mn=Math.round((h-hr)*60),ap=hr>=12?'pm':'am';hr=hr%12||12;return hr+(mn?':'+(mn<10?'0':'')+mn:'')+' '+ap}
try{if(H){var n=pt(),iv=H[n.d]||[],pv=H[(n.d+6)%7]||[],cur=null,nx=null,msg='';
  pv.forEach(function(x){if(x[1]>24&&n.h<x[1]-24)cur=[0,x[1]-24]});
  iv.forEach(function(x){if(n.h>=x[0]&&n.h<x[1])cur=x;else if(x[0]>n.h&&(!nx||x[0]<nx[0]))nx=x});
  if(cur)msg='Open now · until '+fmt(cur[1]);else if(nx)msg='Opens today at '+fmt(nx[0]);
  else{for(var k=1;k<=7;k++){var dd=(n.d+k)%7,x=(H[dd]||[])[0];if(x){msg='Closed · opens '+(k===1?'tomorrow':DN[dd])+' at '+fmt(x[0]);break}}}
  document.querySelectorAll('[data-open-now]').forEach(function(el){el.classList.add(cur?'is-open':'is-closed');var s=el.querySelector('.on-text');if(s&&msg)s.textContent=msg});
  var row=document.querySelector('[data-day="'+n.d+'"]');if(row)row.classList.add('today');
}}catch(e){}
var nav=document.querySelector('nav.nav'),f=document.querySelector('footer.footer');
if(nav&&f){var IW=1440,IH=2560,raf=0;
  function tick(){raf=0;var vw=innerWidth,vh=innerHeight,nr=nav.getBoundingClientRect(),fr=f.getBoundingClientRect();
    R.style.setProperty('--ln-nav-h',Math.round(nr.height)+'px');
    var s=Math.max(vw/IW,vh/IH),bw=Math.ceil(IW*s),bh=Math.ceil(IH*s),ox=Math.min(0,Math.max(vw-bw,vw*.5-bw*.5)),oy=Math.min(0,Math.max(vh-bh,vh*.5-bh*(vw>900?.7:.58)));
    R.style.setProperty('--ln-cbs',bw+'px '+bh+'px');R.style.setProperty('--ln-cnav',(ox-nr.left)+'px '+(oy-nr.top)+'px');R.style.setProperty('--ln-cfoot',(ox-fr.left)+'px '+(oy-fr.top)+'px');
    var wide=vw>900&&!f.classList.contains('footer-reel');R.classList.toggle('ln-wide',wide);
    if(wide){s=Math.max(vw/2100,vh/1400);bw=Math.ceil(2100*s);bh=Math.ceil(1400*s);ox=Math.round((vw-bw)/2);oy=Math.round((vh-bh)/2);
      R.style.setProperty('--ln-cbs',bw+'px '+bh+'px');R.style.setProperty('--ln-cnav',(ox-nr.left)+'px '+(oy-nr.top)+'px');R.style.setProperty('--ln-cfoot',(ox-fr.left)+'px '+(oy-fr.top)+'px')}
    R.style.setProperty('--ln-bs',bw+'px '+bh+'px');
    R.style.setProperty('--ln-nav',(ox-nr.left)+'px '+(oy-nr.top)+'px');
    R.style.setProperty('--ln-foot',(ox-fr.left)+'px '+(oy-fr.top)+'px');
    R.classList.toggle('ln-touch',fr.top-nr.bottom<=14)}
  function q(){if(!raf)raf=requestAnimationFrame(tick)}
  addEventListener('scroll',q,{passive:true});addEventListener('resize',q);addEventListener('load',q);tick();
  var st=0;addEventListener('scroll',function(){clearTimeout(st);st=setTimeout(function(){var g=f.getBoundingClientRect().top-nav.getBoundingClientRect().bottom;if(!matchMedia('(prefers-reduced-motion:reduce)').matches&&g>14&&g<110)scrollBy({top:g,behavior:'smooth'})},140)},{passive:true});
}
var film=document.getElementById('film');
if(film){var fs=[].slice.call(film.querySelectorAll('.fs')),num=film.querySelector('.fm-n'),button=film.querySelector('.film-pause'),mq=matchMedia('(prefers-reduced-motion:reduce)'),paused=mq.matches,cur=-1,fr=0,inView=false;
function sync(){fs.forEach(function(f,j){var v=f.querySelector('video');f.classList.toggle('on',j===cur);if(!v)return;var should=j===cur&&inView&&!document.hidden&&!paused;
if(should){if(v.dataset.src){v.src=v.dataset.src;delete v.dataset.src;v.load()}if(v.paused){var promise=v.play();if(promise&&promise.catch)promise.catch(function(){})}}else if(!v.paused)v.pause()});
if(button){button.textContent=paused?'Play motion':'Pause motion'}}
function ftick(){fr=0;var r=film.getBoundingClientRect(),h=film.offsetHeight-innerHeight,p=Math.min(1,Math.max(0,-r.top/Math.max(1,h)));cur=Math.min(fs.length-1,Math.floor(p*fs.length*1.0001));inView=r.bottom>0&&r.top<innerHeight;film.classList.toggle('past-logo',-r.top>innerHeight*.18);film.style.setProperty('--fp',(p*100).toFixed(1)+'%');if(num)num.textContent=('0'+(cur+1)).slice(-2);sync()}
function queue(){if(!fr)fr=requestAnimationFrame(ftick)}
if(button)button.addEventListener('click',function(){paused=!paused;sync()});
addEventListener('scroll',queue,{passive:true});addEventListener('resize',queue);document.addEventListener('visibilitychange',sync);
if(mq.addEventListener)mq.addEventListener('change',function(){paused=mq.matches;sync()});
film.classList.add('is-ready');ftick();}
var tabs=[].slice.call(document.querySelectorAll('.tab'));
if(tabs.length&&'IntersectionObserver'in window){
  var map={};tabs.forEach(function(b){map[b.dataset.to]=b;b.addEventListener('click',function(){var el=document.getElementById(b.dataset.to);if(el)el.scrollIntoView({behavior:'smooth'})})});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){tabs.forEach(function(b){b.classList.remove('on')});var b=map[e.target.id];if(b){b.classList.add('on');b.parentElement.scrollTo({left:b.offsetLeft-b.parentElement.clientWidth/2+b.offsetWidth/2,behavior:'smooth'})}}})},{rootMargin:'-40% 0px -55% 0px'});
  document.querySelectorAll('.menu-cat').forEach(function(c){io.observe(c)});
}
})();
