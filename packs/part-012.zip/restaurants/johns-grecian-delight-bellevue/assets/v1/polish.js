(()=>{
 document.documentElement.classList.add('lv-polish');
 const footer=document.querySelector('footer.footer'),panel=footer?.querySelector('.foot-links');
 if(!footer||!panel)return;
 const blur=document.createElement('i');blur.className='lv-side-blur';blur.setAttribute('aria-hidden','true');footer.prepend(blur);
 let raf=0;
 function update(){raf=0;const r=footer.getBoundingClientRect(),p=panel.getBoundingClientRect(),css=getComputedStyle(document.documentElement);
  const dims=css.getPropertyValue('--ln-bs').trim(),coords=css.getPropertyValue('--ln-foot').trim().split(/\s+/).map(parseFloat);
  footer.style.setProperty('--lv-blur-top',Math.max(0,p.top-r.top-40)+'px');
  if(dims&&coords.length===2&&coords.every(Number.isFinite)){
   panel.style.setProperty('--lv-panel-size',dims);
   panel.style.setProperty('--lv-panel-pos',(coords[0]-(p.left-r.left)-panel.clientLeft)+'px '+(coords[1]-(p.top-r.top)-panel.clientTop)+'px');
  }
 }
 function queue(){if(!raf)raf=requestAnimationFrame(update)}
 addEventListener('scroll',queue,{passive:true});addEventListener('resize',queue);addEventListener('load',queue);
 if('ResizeObserver'in window)new ResizeObserver(queue).observe(footer);
 document.fonts?.ready.then(queue);queue();
})();
