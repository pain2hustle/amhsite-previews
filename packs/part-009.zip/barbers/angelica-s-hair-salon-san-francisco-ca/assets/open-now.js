(function () {
  var H = {"0": null, "1": null, "2": null, "3": null, "4": null, "5": null, "6": null}, TZ = "America/Los_Angeles";
  var DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  function now() {
    var o = {};
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: TZ, weekday: 'short', hour: 'numeric', minute: 'numeric', hour12: false })
        .formatToParts(new Date()).forEach(function (p) { o[p.type] = p.value; });
      return { d: DAYS.indexOf(o.weekday), h: (parseInt(o.hour, 10) % 24) + parseInt(o.minute, 10) / 60 };
    } catch (e) { var n = new Date(); return { d: n.getDay(), h: n.getHours() + n.getMinutes() / 60 }; }
  }
  function fmt(h) { var hr = Math.floor(h), m = Math.round((h - hr) * 60); return (hr % 12 || 12) + (m ? ':' + (m < 10 ? '0' : '') + m : '') + (hr >= 12 && hr < 24 ? ' PM' : ' AM'); }
  function nextOpen(t) {
    for (var i = 0; i < 8; i++) { var d = (t.d + i) % 7, r = H[d];
      if (!r) continue; for (var j = 0; j < r.length; j++) { if (i > 0 || r[j][0] > t.h) return { i: i, d: d, h: r[j][0] }; } }
    return null;
  }
  function state() {
    var t = now(), r = H[t.d];
    if (r === undefined || (r === null && !Object.keys(H).some(function (k) { return H[k]; }))) return null;
    if (r) for (var j = 0; j < r.length; j++) if (t.h >= r[j][0] && t.h < r[j][1]) return { open: true, text: 'Open now · till ' + fmt(r[j][1]) };
    var n = nextOpen(t); if (!n) return null;
    return { open: false, text: 'Closed · opens ' + fmt(n.h) + (n.i === 0 ? ' today' : n.i === 1 ? ' tomorrow' : ' ' + DAYS[n.d]) };
  }
  function paint() {
    var s = state(); if (!s) return;
    document.querySelectorAll('[data-open-now]').forEach(function (el) {
      el.classList.toggle('is-open', s.open); el.classList.toggle('is-closed', !s.open);
      var t = el.querySelector('.on-text'); if (t) t.textContent = s.text;
    });
  }
  paint(); setInterval(paint, 30000);
})();
