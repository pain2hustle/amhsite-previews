(()=>{'use strict';
const root=document.documentElement;root.classList.add('cg-js');
const toggle=document.getElementById('menuToggle'),menu=document.getElementById('mobileMenu');
function closeMenu(){if(!menu||!toggle)return;menu.hidden=true;menu.classList.remove('open');toggle.classList.remove('open');toggle.setAttribute('aria-expanded','false');}
toggle?.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';menu.hidden=!open;menu.classList.toggle('open',open);toggle.classList.toggle('open',open);toggle.setAttribute('aria-expanded',String(open));});
menu?.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();toggle?.focus();}});
const WEEK=[[],[[390,840]],[[390,840]],[[390,840]],[[390,840]],[[390,840]],[[420,750]]];
function updateHours(now=new Date()){
 try{const p=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(x=>[x.type,x.value]));const d=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(p.weekday),m=Number(p.hour)*60+Number(p.minute);if(d<0||!Number.isFinite(m))throw Error('time');const open=WEEK[d].some(([a,b])=>m>=a&&m<b);
 document.querySelectorAll('[data-open-now]').forEach(el=>{el.classList.toggle('is-open',open);el.classList.toggle('is-closed',!open);el.querySelector('.on-text').textContent=open?'Open':'Closed';el.title='Based on regular Google hours in America/New_York. Holiday or special hours may differ.';});document.querySelectorAll('[data-day]').forEach(el=>el.classList.toggle('today',Number(el.dataset.day)===d));
 }catch(e){document.querySelectorAll('[data-open-now]').forEach(el=>{el.classList.remove('is-open','is-closed');el.querySelector('.on-text').textContent='Call for hours';});}}
updateHours();setInterval(updateHours,60000);
const film=document.getElementById('film'),scenes=Array.from(film?.querySelectorAll('.fs')||[]),motion=matchMedia('(prefers-reduced-motion:reduce)'),button=document.getElementById('filmToggle');let paused=false,frame=0;
function paint(){frame=0;if(!film||!scenes.length)return;const r=film.getBoundingClientRect(),range=Math.max(1,film.offsetHeight-innerHeight),p=Math.min(1,Math.max(0,-r.top/range)),i=motion.matches?0:Math.min(scenes.length-1,Math.floor(p*scenes.length*1.0001)),visible=r.bottom>0&&r.top<innerHeight&&!document.hidden;
 scenes.forEach((scene,j)=>{const active=j===i;scene.classList.toggle('on',active);scene.setAttribute('aria-hidden',String(!active));const v=scene.querySelector('video');if(!v)return;if(active&&visible&&!paused&&!motion.matches){v.preload='auto';if(v.paused){const promise=v.play();promise?.catch(()=>{});}}else v.pause();});
 film.style.setProperty('--fp',(p*100).toFixed(1)+'%');film.classList.toggle('past-logo',-r.top>innerHeight*.18);const n=film.querySelector('.fm-n');if(n)n.textContent=String(i+1).padStart(2,'0');}
function queue(){if(!frame)frame=requestAnimationFrame(paint);}
button?.addEventListener('click',()=>{paused=!paused;button.textContent=paused?'Play motion':'Pause motion';button.setAttribute('aria-pressed',String(paused));paint();});
addEventListener('scroll',queue,{passive:true});addEventListener('resize',queue);addEventListener('load',queue);document.addEventListener('visibilitychange',queue);motion.addEventListener?.('change',queue);paint();
document.querySelectorAll('video').forEach(v=>v.addEventListener('error',()=>{v.hidden=true;}));
})();
