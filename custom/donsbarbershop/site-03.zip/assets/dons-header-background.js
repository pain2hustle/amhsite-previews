(function () {
  'use strict';
  const nav = document.querySelector('nav.nav');
  const leather = document.querySelector('main .hero');
  if (!nav || !leather) return;
  let queued = false;
  function paint() {
    queued = false;
    nav.classList.toggle('dons-leather', leather.getBoundingClientRect().top <= nav.getBoundingClientRect().bottom);
  }
  function schedule() { if (!queued) { queued = true; requestAnimationFrame(paint); } }
  window.addEventListener('scroll', schedule, {passive: true});
  window.addEventListener('resize', schedule, {passive: true});
  window.addEventListener('pageshow', schedule);
  window.addEventListener('load', schedule);
  paint();
}());
