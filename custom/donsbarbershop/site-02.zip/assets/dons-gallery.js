(function () {
  'use strict';
  const overlay = document.getElementById('barberDlg');
  if (!overlay) return;
  const dialog = overlay.querySelector('[role="dialog"]');
  const listView = document.getElementById('dgListView');
  const viewer = document.getElementById('dgViewer');
  const list = document.getElementById('dgThumbnails');
  const photo = document.getElementById('bdImg');
  const caption = document.getElementById('bdCap');
  const count = document.getElementById('dgCount');
  const closeButton = overlay.querySelector('.bd-x');
  const allButton = document.getElementById('dgAll');
  const photos = [
  {
    "src": "./assets/shop/gallery-side.jpg",
    "title": "Side view",
    "alt": "Haircut, side view"
  },
  {
    "src": "./assets/shop/gallery-front.jpg",
    "title": "Front view",
    "alt": "Haircut, front view"
  },
  {
    "src": "./assets/shop/gallery-03.jpg",
    "title": "Comb-over",
    "alt": "Comb-over at Don's Barber Shop"
  },
  {
    "src": "./assets/shop/gallery-04.jpg",
    "title": "Styled top",
    "alt": "Styled top at Don's Barber Shop"
  },
  {
    "src": "./assets/shop/gallery-05.jpg",
    "title": "Rear fade",
    "alt": "Rear fade at Don's Barber Shop"
  },
  {
    "src": "./assets/shop/gallery-06.jpg",
    "title": "Classic cut",
    "alt": "Classic cut at Don's Barber Shop"
  }
];
  let portraitMode = false;
  let index = 0, opener = null, priorOverflow = '', pageY = 0;
  const background = [];
  const thumbnails = photos.map((item, i) => {
    const li = document.createElement('li');
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'dg-thumbnail';
    button.setAttribute('aria-label', 'Open ' + item.title.toLowerCase() + ', photo ' + (i + 1) + ' of ' + photos.length);
    const img = document.createElement('img');
    img.src = item.src; img.alt = ''; img.width = 1368; img.height = 1824;
    const label = document.createElement('span'); label.textContent = item.title;
    button.append(img, label); li.append(button); list.append(li);
    button.addEventListener('click', () => showPhoto(i, true));
    return button;
  });
  function showList(restoreFocus) {
    portraitMode = false; viewer.classList.remove('portrait-view'); viewer.hidden = true; listView.hidden = false;
    if (restoreFocus) thumbnails[index].focus();
  }
  function showPhoto(i, focusViewer) {
    portraitMode = false; viewer.classList.remove('portrait-view');
    document.getElementById('dgPrev').hidden=false; document.getElementById('dgNext').hidden=false;
    index = (i + photos.length) % photos.length;
    const item = photos[index]; photo.src = item.src; photo.alt = item.alt;
    caption.textContent = item.title;
    count.textContent = 'Photo ' + (index + 1) + ' of ' + photos.length;
    listView.hidden = true; viewer.hidden = false;
    if (focusViewer) allButton.focus();
  }
  function open(button, i) {
    opener = button; pageY = window.scrollY; priorOverflow = document.body.style.overflow;
    overlay.hidden = false; overlay.setAttribute('aria-hidden', 'false'); document.body.style.overflow = 'hidden';
    background.length = 0;
    [...document.body.children].filter(el => el !== overlay && !['SCRIPT', 'STYLE'].includes(el.tagName)).forEach(el => {
      background.push([el, el.inert]); el.inert = true;
    });
    if (Number.isInteger(i)) showPhoto(i, false); else showList(false);
    closeButton.focus();
  }
  function showPortrait(button) {
    open(button); portraitMode=true; viewer.classList.add('portrait-view');
    listView.hidden=true; viewer.hidden=false; photo.src='./assets/shop/don-original.jpg'; photo.alt='Don';
    caption.textContent='Don'; count.textContent='Portrait';
    document.getElementById('dgPrev').hidden=true; document.getElementById('dgNext').hidden=true;
  }
  document.querySelectorAll('[data-don-portrait]').forEach(button=>button.addEventListener('click',()=>showPortrait(button)));
  function close() {
    if (overlay.hidden) return;
    overlay.hidden = true; overlay.setAttribute('aria-hidden', 'true');
    background.forEach(([el, inert]) => { el.inert = inert; });
    document.body.style.overflow = priorOverflow; window.scrollTo({top: pageY, behavior: 'instant'});
    if (opener) opener.focus({preventScroll: true});
  }
  document.querySelectorAll('[data-gallery-list]').forEach(button => button.addEventListener('click', () => open(button)));
  document.querySelectorAll('[data-gallery]').forEach(button => {
    button.addEventListener('click', () => open(button, Number(button.dataset.gallery)));
    button.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(button, Number(button.dataset.gallery)); }
    });
  });
  closeButton.addEventListener('click', close);
  overlay.addEventListener('click', event => { if (event.target === overlay) close(); });
  allButton.addEventListener('click', () => showList(true));
  document.getElementById('dgPrev').addEventListener('click', () => showPhoto(index - 1, false));
  document.getElementById('dgNext').addEventListener('click', () => showPhoto(index + 1, false));
  document.addEventListener('keydown', event => {
    if (overlay.hidden) return;
    if (event.key === 'Escape') { event.preventDefault(); close(); }
    if (!portraitMode && !viewer.hidden && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) {
      event.preventDefault(); showPhoto(index + (event.key === 'ArrowLeft' ? -1 : 1), false);
    }
    if (event.key === 'Tab') {
      const focusable = [...dialog.querySelectorAll('button:not([disabled]),a[href],[tabindex="0"]')].filter(el => el.getClientRects().length);
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
})();
