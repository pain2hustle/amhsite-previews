(function(){
  // No current authoritative complete week is verified; never infer opening state from stale/conflicting listings.
  function status(){return {state:'unknown',text:'Call to confirm hours'};}
  function paint(){const s=status();document.querySelectorAll('[data-open-now]').forEach(el=>{['open','closed','unknown'].forEach(k=>el.classList.toggle('is-'+k,s.state===k));const t=el.querySelector('.on-text');if(t)t.textContent=s.text;});}
  window.DonsHours={status};paint();
})();
