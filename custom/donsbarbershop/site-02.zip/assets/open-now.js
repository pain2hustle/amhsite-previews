(function () {
  'use strict';
  const zone = 'America/Los_Angeles';
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const week = [[600, 960], null, [540, 1080], [540, 1080], [540, 1080], [540, 1080], [480, 900]];
  const clock = new Intl.DateTimeFormat('en-US', {timeZone: zone, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23'});
  function label(minutes) {
    const hour = Math.floor(minutes / 60);
    const minute = minutes % 60;
    return (hour % 12 || 12) + (minute ? ':' + String(minute).padStart(2, '0') : '') + (hour < 12 ? ' AM' : ' PM');
  }
  function status(now = new Date()) {
    const parts = Object.fromEntries(clock.formatToParts(now).map(p => [p.type, p.value]));
    const day = days.indexOf(parts.weekday), minute = Number(parts.hour) * 60 + Number(parts.minute);
    const today = week[day];
    if (today && minute >= today[0] && minute < today[1]) return {state: 'open', text: 'Open now · until ' + label(today[1]) + ' PT'};
    if (today && minute < today[0]) return {state: 'closed', text: 'Closed · opens ' + label(today[0]) + ' today PT'};
    for (let offset = 1; offset <= 7; offset++) {
      const next = (day + offset) % 7;
      if (week[next]) return {state: 'closed', text: 'Closed · opens ' + label(week[next][0]) + ' ' + (offset === 1 ? 'tomorrow' : days[next]) + ' PT'};
    }
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = {status, week, zone};
  if (typeof document === 'undefined') return;
  function paint() {
    const s = status();
    document.querySelectorAll('[data-open-now]').forEach(el => {
      ['open', 'closed', 'unknown'].forEach(k => el.classList.toggle('is-' + k, s.state === k));
      const text = el.querySelector('.on-text');
      if (text) text.textContent = s.text;
    });
  }
  window.DonsHours = Object.freeze({status});
  paint();
  setInterval(paint, 30000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) paint(); });
}());
