(() => {
  'use strict';
  const id = 'dons-logo-white-key-v2';
  const filter = `<defs><filter id="${id}" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
    <feColorMatrix in="SourceGraphic" type="matrix" values="1 0 0 0 0  1 0 0 0 0  1 0 0 0 0  0 0 0 1 0" result="r"/>
    <feColorMatrix in="SourceGraphic" type="matrix" values="0 1 0 0 0  0 1 0 0 0  0 1 0 0 0  0 0 0 1 0" result="g"/>
    <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 1 0 0  0 0 1 0 0  0 0 1 0 0  0 0 0 1 0" result="b"/>
    <feBlend in="r" in2="g" mode="darken" result="rg"/>
    <feBlend in="rg" in2="b" mode="darken" result="rgbmin"/>
    <feColorMatrix in="rgbmin" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -1 0 0 0 1" result="key"/>
    <feComponentTransfer in="key" result="alpha"><feFuncA type="linear" slope="20" intercept="-0.2"/></feComponentTransfer>
    <feComposite in="SourceGraphic" in2="alpha" operator="in"/>
  </filter></defs>`;
  if (!document.getElementById(id)) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'dons-logo-filter-definitions');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.innerHTML = filter;
    document.body.prepend(svg);
  }
  function set(mode) {
    const active = mode === 'white-key';
    document.documentElement.classList.toggle('dons-logo-review-key', active);
    document.documentElement.dataset.donsLogoPresentation = active ? 'white-key-candidate' : 'original';
    return active ? 'white-key' : 'original';
  }
  const mode = new URLSearchParams(location.search).get('logo_presentation');
  set(mode);
  // No storage or default-on mutation: remove the query string to return to v1.
  window.DonsLogoPresentation = Object.freeze({ set, filterId: id, renderedReviewPassed: false });
})();
