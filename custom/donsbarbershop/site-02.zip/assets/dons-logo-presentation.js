/* Exact artwork is presented through self-contained SVGs. No runtime logo swap. */
