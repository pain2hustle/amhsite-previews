/* 2026-09-29 Austin: browser bar matches the site + installable as an app.
   Phones (Samsung Internet / Chrome Android) paint the top bar from <meta name="theme-color">.
   The nav always sits right under that bar, so the bar takes the nav's top-edge colour:
   warm shop brown normally, near-black when the footer's crew photo takes over the nav (html.rl-touch). */
(function () {
  var R = document.documentElement;
  var m = document.querySelector('meta[name="theme-color"]');
  if (!m) { m = document.createElement('meta'); m.name = 'theme-color'; document.head.appendChild(m); }
  var NAV = '#3f2812', TOUCH = '#120d07', cur = '';
  function set() {
    var c = R.classList.contains('rl-touch') ? TOUCH : NAV;
    if (c !== cur) { cur = c; m.setAttribute('content', c); }
  }
  set();
  try { new MutationObserver(set).observe(R, { attributes: true, attributeFilter: ['class'] }); } catch (e) {}
  // installable app (Chrome / Edge / Samsung): a pass-through service worker, no caching

})();
