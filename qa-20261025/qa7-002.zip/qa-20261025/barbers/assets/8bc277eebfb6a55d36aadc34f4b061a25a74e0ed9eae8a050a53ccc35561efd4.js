/* Royal Luxe Cutz scroll film (scenes 02-08 from the Grok cut, rebuilt on this site's own page).
   Scroll position drives which scene is on screen, its camera move and its caption.
   Camera + cross-fade curves match the original so the movie feels the same. */
(function () {
  var film = document.getElementById('film');
  if (!film) return;
  var layers = [].slice.call(film.querySelectorAll('.layer'));
  var caps = [].slice.call(film.querySelectorAll('.cap > div'));
  var n = layers.length;
  if (!n) return;
  document.documentElement.classList.add('amh-film-ready');
  var railFill = film.querySelector('.rail i');
  var nowEl = film.querySelector('.meta b');
  var cue = film.querySelector('.cue');
  var motionQuery = matchMedia('(prefers-reduced-motion: reduce)');
  var reduce = motionQuery.matches, paused = reduce, userPlayed = false;
  var button = film.querySelector('.film-pause'), inView = false, currentShot = 0;
  function syncVideos() {
    layers.forEach(function (el, i) {
      var v = el.querySelector('video'); if (!v) return;
      var shouldPlay = i === currentShot && inView && !document.hidden && !paused && (!reduce || userPlayed);
      if (shouldPlay) {
        if (v.dataset.src) { v.src = v.dataset.src; v.removeAttribute('data-src'); v.load(); }
        if (v.paused) { var promise = v.play(); if (promise && promise.catch) promise.catch(function () { if (i === currentShot && inView && !paused) { paused = true; userPlayed = false; if (button) button.textContent = 'Play motion'; } }); }
      } else if (!v.paused) v.pause();
    });
    if (button) button.textContent = paused || (reduce && !userPlayed) ? 'Play motion' : 'Pause motion';
  }

  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }

  // cross-fade: each scene owns a slot and bleeds .22 of a slot into its neighbours
  function alpha(p, i) {
    var r = p - i, edge = 0.22;
    if (r <= -edge || r >= 1 + edge) return 0;
    var a = 1;
    if (i !== 0 && r < edge) a = (r + edge) / (edge * 2);
    if (i !== n - 1 && r > 0.78) a = Math.min(a, (1 + edge - r) / (edge * 2));
    return clamp(a, 0, 1);
  }

  // camera moves, one per scene kind
  function cam(kind, t) {
    var k = clamp(t, 0, 1);
    if (kind === 'push') return 'translate3d(0,' + (k * -2.5) + '%,0) scale(' + (1.06 + k * 0.2) + ')';
    if (kind === 'pan') return 'translate3d(' + (5 - k * 10) + '%,0,0) scale(1.16)';
    if (kind === 'drift') return 'translate3d(' + ((k - 0.5) * 4) + '%,' + (k * 2) + '%,0) scale(' + (1.12 - k * 0.05) + ')';
    if (kind === 'pull') return 'translate3d(0,' + ((0.4 - k) * 2) + '%,0) scale(' + (1.18 - k * 0.12) + ')';
    return 'translate3d(0,0,0) scale(1.04)';
  }

  var ticking = false, lastShot = -1;
  function frame() {
    ticking = false;
    var box = film.getBoundingClientRect();
    var vh = innerHeight || document.documentElement.clientHeight;
    var travel = film.offsetHeight - vh;
    var p = travel > 0 ? clamp(-box.top / travel, 0, 1) : 0;
    var pos = p * n;                       // 0 .. n, the scene cursor
    var shot = clamp(Math.floor(pos), 0, n - 1);
    currentShot = shot; inView = box.bottom > 0 && box.top < vh;

    for (var i = 0; i < n; i++) {
      var el = layers[i];
      var a = alpha(pos, i);
      el.style.opacity = a;
      el.style.visibility = a > 0.004 ? 'visible' : 'hidden';
      if (a > 0.004 && !reduce) {
        var media = el.firstElementChild;
        if (media) media.style.transform = cam(el.dataset.cam, pos - i);
      }
      var cap = caps[i];
      if (cap) {
        // the words arrive a beat after the picture and leave before the cut
        var t = pos - i;
        var ca = t < 0.06 ? clamp((t + 0.1) / 0.16, 0, 1) : t > 0.82 ? clamp((1.02 - t) / 0.2, 0, 1) : 1;
        ca = clamp(ca, 0, 1) * (a > 0.06 ? 1 : 0);
        cap.style.opacity = ca;
        cap.style.transform = 'translateY(' + ((1 - ca) * 14) + 'px)';
        cap.style.visibility = ca > 0.01 ? 'visible' : 'hidden';
      }
    }

    if (railFill) railFill.style.width = (p * 100).toFixed(2) + '%';
    if (shot !== lastShot) {
      lastShot = shot;
      if (nowEl) nowEl.textContent = String(shot + 1).padStart(2, '0');   // 01..08, our own cut
    }
    syncVideos();
    if (cue) cue.style.opacity = p > 0.04 ? '0' : '1';
  }

  function onScroll() { if (!ticking) { ticking = true; requestAnimationFrame(frame); } }
  addEventListener('scroll', onScroll, { passive: true });
  addEventListener('resize', onScroll);

  if (button) {
    button.hidden = false;
    button.addEventListener('click', function () { paused = !paused; userPlayed = !paused; syncVideos(); });
  }
  document.addEventListener('visibilitychange', syncVideos);
  function preferenceChanged() { reduce = motionQuery.matches; paused = reduce; userPlayed = false; onScroll(); }
  if (motionQuery.addEventListener) motionQuery.addEventListener('change', preferenceChanged);
  else if (motionQuery.addListener) motionQuery.addListener(preferenceChanged);

  frame();
})();
